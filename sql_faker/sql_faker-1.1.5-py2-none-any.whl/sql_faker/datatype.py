# coding=utf-8

class DataType:
    """数据类型"""
    ID = "ID"
    USERNAME = "USERNAME"
    PHONE = "PHONE"
    TIME = "TIME"
    ADDRESS = "ADDRESS"
    AGE = "AGE"
    SEX = "SEX"
    EMAIL = "EMAIL"
